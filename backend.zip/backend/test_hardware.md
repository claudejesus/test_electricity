02:33:28.331 -> GET Payload: [{"tenant_id":"1","current_kw":"2.178","status":"connected"},{"tenant_id":"2","current_kw":"0","status":"disconnected"},{"tenant_id":"3","current_kw":"0.53","status":"connected"}]
02:33:28.331 -> Tenant 1 → V: 2.18 V, I: 0.00 A, P: 0.00 kW
02:33:28.331 -> Relay OFF for Tenant 1
02:33:29.339 -> Tenant 2 → V: 0.00 V, I: 0.00 A, P: 0.00 kW
02:33:29.339 -> Relay OFF for Tenant 2
02:33:35.369 -> GET Payload: [{"tenant_id":"1","current_kw":"2.178","status":"connected"},{"tenant_id":"2","current_kw":"0","status":"disconnected"},{"tenant_id":"3","current_kw":"0.53","status":"connected"}]
02:33:35.418 -> Tenant 1 → V: 2.16 V, I: 0.00 A, P: 0.00 kW
02:33:35.418 -> Relay OFF for Tenant 1
02:33:36.422 -> Tenant 2 → V: 0.00 V, I: 0.00 A, P: 0.00 kW
02:33:36.422 -> Relay OFF for Tenant 2
02:33:42.448 -> GET Payload: [{"tenant_id":"1","current_kw":"2.178","status":"connected"},{"tenant_id":"2","current_kw":"0","status":"disconnected"},{"tenant_id":"3","current_kw":"0.53","status":"connected"}]
02:33:42.448 -> Tenant 1 → V: 2.15 V, I: 0.00 A, P: 0.00 kW
02:33:42.448 -> Relay OFF for Tenant 1
02:33:43.458 -> Tenant 2 → V: 0.00 V, I: 0.00 A, P: 0.00 kW
02:33:43.458 -> Relay OFF for Tenant 2
02:33:49.488 -> GET Payload: [{"tenant_id":"1","current_kw":"2.178","status":"connected"},{"tenant_id":"2","current_kw":"0","status":"disconnected"},{"tenant_id":"3","current_kw":"0.53","status":"connected"}]
02:33:49.488 -> Tenant 1 → V: 2.16 V, I: 0.00 A, P: 0.00 kW
02:33:49.488 -> Relay OFF for Tenant 1
02:33:50.479 -> Tenant 2 → V: 0.00 V, I: 0.00 A, P: 0.00 kW
02:33:50.479 -> Relay OFF for Tenant 2
02:33:56.513 -> GET Payload: [{"tenant_id":"1","current_kw":"2.178","status":"connected"},{"tenant_id":"2","current_kw":"0","status":"disconnected"},{"tenant_id":"3","current_kw":"0.53","status":"connected"}]
02:33:56.513 -> Tenant 1 → V: 2.15 V, I: 0.00 A, P: 0.00 kW
02:33:56.561 -> Relay OFF for Tenant 1
02:33:57.555 -> Tenant 2 → V: 0.00 V, I: 0.00 A, P: 0.00 kW
02:33:57.555 -> Relay OFF for Tenant 2
02:34:03.713 -> GET Payload: [{"tenant_id":"1","current_kw":"2.178","status":"connected"},{"tenant_id":"2","current_kw":"0","status":"disconnected"},{"tenant_id":"3","current_kw":"0.53","status":"connected"}]
02:34:03.713 -> Tenant 1 → V: 2.17 V, I: 0.00 A, P: 0.00 kW
02:34:03.713 -> Relay OFF for Tenant 1
02:34:04.716 -> Tenant 2 → V: 0.00 V, I: 0.00 A, P: 0.00 kW
02:34:04.716 -> Relay OFF for Tenant 2
02:34:10.743 -> GET Payload: [{"tenant_id":"1","current_kw":"2.178","status":"connected"},{"tenant_id":"2","current_kw":"0","status":"disconnected"},{"tenant_id":"3","current_kw":"0.53","status":"connected"}]
02:34:10.790 -> Tenant 1 → V: 2.18 V, I: 0.00 A, P: 0.00 kW
02:34:10.790 -> Relay OFF for Tenant 1
02:34:11.754 -> Tenant 2 → V: 0.00 V, I: 0.00 A, P: 0.00 kW
02:34:11.754 -> Relay OFF for Tenant 2
02:34:17.825 -> GET Payload: [{"tenant_id":"1","current_kw":"2.178","status":"connected"},{"tenant_id":"2","current_kw":"0","status":"disconnected"},{"tenant_id":"3","current_kw":"0.53","status":"connected"}]
02:34:17.825 -> Tenant 1 → V: 2.17 V, I: 0.00 A, P: 0.00 kW
02:34:17.825 -> Relay OFF for Tenant 1
02:34:18.834 -> Tenant 2 → V: 0.00 V, I: 0.00 A, P: 0.00 kW
02:34:18.834 -> Relay OFF for Tenant 2
02:34:24.860 -> GET Payload: [{"tenant_id":"1","current_kw":"2.178","status":"connected"},{"tenant_id":"2","current_kw":"0","status":"disconnected"},{"tenant_id":"3","current_kw":"0.53","status":"connected"}]
02:34:24.860 -> Tenant 1 → V: 2.09 V, I: 0.00 A, P: 0.00 kW
02:34:24.860 -> Relay OFF for Tenant 1
02:34:25.866 -> Tenant 2 → V: 0.00 V, I: 0.00 A, P: 0.00 kW
02:34:25.866 -> Relay OFF for Tenant 2
02:34:31.899 -> GET Payload: [{"tenant_id":"1","current_kw":"2.178","status":"connected"},{"tenant_id":"2","current_kw":"0","status":"disconnected"},{"tenant_id":"3","current_kw":"0.53","status":"connected"}]
02:34:31.899 -> Tenant 1 → V: 2.05 V, I: 0.00 A, P: 0.00 kW
02:34:31.899 -> Relay OFF for Tenant 1
02:34:32.905 -> Tenant 2 → V: 0.00 V, I: 0.00 A, P: 0.00 kW
02:34:32.905 -> Relay OFF for Tenant 2

### ###########################
2:43:28.414 -> GET Payload: [{"tenant_id":"1","current_kw":"2.178","status":"connected"},{"tenant_id":"3","current_kw":"0.53","status":"connected"}]
02:43:28.414 -> Tenant 1 → V: 2.22 V, I: 0.00 A, P: 0.00 kW
02:43:28.414 -> Relay OFF for Tenant 1
02:43:29.422 -> Tenant 2 → V: 0.00 V, I: 0.00 A, P: 0.00 kW
02:43:29.422 -> Relay OFF for Tenant 2
02:43:35.464 -> GET Payload: [{"tenant_id":"1","current_kw":"2.178","status":"connected"},{"tenant_id":"3","current_kw":"0.53","status":"connected"}]
02:43:35.464 -> Tenant 1 → V: 2.21 V, I: 0.00 A, P: 0.00 kW
02:43:35.464 -> Relay OFF for Tenant 1
02:43:36.472 -> Tenant 2 → V: 0.00 V, I: 0.00 A, P: 0.00 kW
02:43:36.472 -> Relay OFF for Tenant 2
02:43:42.534 -> GET Payload: [{"tenant_id":"1","current_kw":"2.178","status":"connected"},{"tenant_id":"3","current_kw":"0.53","status":"connected"}]
02:43:42.534 -> Tenant 1 → V: 2.23 V, I: 0.00 A, P: 0.00 kW
02:43:42.534 -> Relay OFF for Tenant 1
02:43:43.540 -> Tenant 2 → V: 0.00 V, I: 0.00 A, P: 0.00 kW
02:43:43.540 -> Relay OFF for Tenant 2
02:43:49.586 -> GET Payload: [{"tenant_id":"1","current_kw":"2.178","status":"connected"},{"tenant_id":"3","current_kw":"0.53","status":"connected"}]
02:43:49.586 -> Tenant 1 → V: 2.23 V, I: 0.00 A, P: 0.00 kW
02:43:49.586 -> Relay OFF for Tenant 1
02:43:50.580 -> Tenant 2 → V: 0.00 V, I: 0.00 A, P: 0.00 kW
02:43:50.580 -> Relay OFF for Tenant 2
### 

final 


02:50:19.699 -> ets Jul 29 2019 12:21:46
02:50:19.699 -> 
02:50:19.699 -> rst:0x1 (POWERON_RESET),boot:0x13 (SPI_FAST_FLASH_BOOT)
02:50:19.699 -> configsip: 0, SPIWP:0xee
02:50:19.699 -> clk_drv:0x00,q_drv:0x00,d_drv:0x00,cs0_drv:0x00,hd_drv:0x00,wp_drv:0x00
02:50:19.699 -> mode:DIO, clock div:1
02:50:19.699 -> load:0x3fff0030,len:4888
02:50:19.699 -> load:0x40078000,len:16516
02:50:19.699 -> load:0x40080400,len:4
02:50:19.699 -> load:0x40080404,len:3476
02:50:19.699 -> entry 0x400805b4
02:50:20.131 -> Connecting to WiFi....
02:50:22.096 -> Connected!
02:50:22.146 -> GET Payload: [{"tenant_id":"1","current_kw":"2.178","status":"connected"},{"tenant_id":"2","current_kw":"0.53","status":"connected"}]
02:50:22.191 -> Tenant 1 → V: 2.22 V, I: 0.00 A, P: 0.00 kW
02:50:22.191 -> Relay OFF for Tenant 1
02:50:23.199 -> Tenant 2 → V: 0.00 V, I: 0.00 A, P: 0.00 kW
02:50:23.199 -> Relay OFF for Tenant 2
02:50:29.219 -> GET Payload: [{"tenant_id":"1","current_kw":"2.178","status":"connected"},{"tenant_id":"2","current_kw":"0.53","status":"connected"}]
02:50:29.219 -> Tenant 1 → V: 2.18 V, I: 0.00 A, P: 0.00 kW
02:50:29.219 -> Relay OFF for Tenant 1
02:50:30.223 -> Tenant 2 → V: 0.00 V, I: 0.00 A, P: 0.00 kW
02:50:30.223 -> Relay OFF for Tenant 2
02:50:36.263 -> GET Payload: [{"tenant_id":"1","current_kw":"2.178","status":"connected"},{"tenant_id":"2","current_kw":"0.53","status":"connected"}]
02:50:36.263 -> Tenant 1 → V: 2.20 V, I: 0.00 A, P: 0.00 kW
02:50:36.263 -> Relay OFF for Tenant 1
02:50:37.265 -> Tenant 2 → V: 0.00 V, I: 0.00 A, P: 0.00 kW
02:50:37.265 -> Relay OFF for Tenant 2
